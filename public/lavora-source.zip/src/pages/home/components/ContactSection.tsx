import { useState } from 'react';
import { motion } from 'framer-motion';

const ContactSection = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        message: '',
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        console.log('Form submitted:', formData);
        alert('Mesajınız alındı. En kısa sürede dönüş yapacağız.');
    };

    return (
        <section id="contact" className="relative py-24 bg-gradient-to-br from-nardo-dark via-matte to-nardo-dark border-t border-white/5">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16">
                    <span className="px-4 py-1.5 bg-gold-DEFAULT/10 rounded-full text-gold-DEFAULT text-xs uppercase tracking-widest">İletişim</span>
                    <h2 className="text-5xl font-playfair text-white mt-6">Bize Ulaşın</h2>
                    <div className="w-12 h-[2px] bg-gold-DEFAULT mx-auto mt-6"></div>
                    <p className="text-gray-400 mt-6 max-w-lg mx-auto">Projeleriniz için bizimle iletişime geçin</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
                    {/* Contact info cards */}
                    <motion.div
                        initial={{ opacity: 0, x: -50 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.6 }}
                        className="space-y-6"
                    >
                        {[
                            { title: "Adres", content: "Yukarı Dudullu Mah. Feza Sok. No:4/B\nÜmraniye, İstanbul", icon: "ri-map-pin-line" },
                            { title: "Telefon", content: "+90 537 580 32 96", icon: "ri-phone-line" },
                            { title: "E-posta", content: "info@lavoradesign.com", icon: "ri-mail-line" }
                        ].map((item, i) => (
                            <div key={i} className="flex p-8 bg-white/5 rounded-lg border border-white/5 hover:border-gold-DEFAULT/30 transition-all items-start gap-6 group">
                                <div className="w-12 h-12 bg-gold-DEFAULT/10 rounded-full flex items-center justify-center shrink-0 group-hover:bg-gold-DEFAULT group-hover:text-matte transition-colors text-gold-DEFAULT">
                                    <i className={`${item.icon} text-xl`}></i>
                                </div>
                                <div>
                                    <h3 className="text-xl font-playfair text-white mb-2">{item.title}</h3>
                                    <p className="text-gray-400 font-montserrat whitespace-pre-line">{item.content}</p>
                                </div>
                            </div>
                        ))}
                    </motion.div>

                    {/* Contact form */}
                    <motion.div
                        initial={{ opacity: 0, x: 50 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.6 }}
                        className="bg-white/5 p-8 sm:p-12 rounded-2xl border border-white/5"
                    >
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="space-y-2">
                                <label className="text-gray-400 text-sm">Ad Soyad</label>
                                <input
                                    type="text"
                                    className="w-full bg-black/40 border border-white/10 rounded-full px-6 py-4 text-white focus:border-gold-DEFAULT outline-none transition-colors"
                                    placeholder="Adınız ve soyadınız"
                                    value={formData.name}
                                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-gray-400 text-sm">E-posta</label>
                                <input
                                    type="email"
                                    className="w-full bg-black/40 border border-white/10 rounded-full px-6 py-4 text-white focus:border-gold-DEFAULT outline-none transition-colors"
                                    placeholder="E-posta adresiniz"
                                    value={formData.email}
                                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-gray-400 text-sm">Telefon</label>
                                <input
                                    type="tel"
                                    className="w-full bg-black/40 border border-white/10 rounded-full px-6 py-4 text-white focus:border-gold-DEFAULT outline-none transition-colors"
                                    placeholder="Telefon numaranız"
                                    value={formData.phone}
                                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-gray-400 text-sm">Mesajınız</label>
                                <textarea
                                    rows={4}
                                    maxLength={500}
                                    className="w-full bg-black/40 border border-white/10 rounded-2xl px-6 py-4 text-white focus:border-gold-DEFAULT outline-none transition-colors resize-none"
                                    placeholder="Mesajınızı buraya yazın... (Maksimum 500 karakter)"
                                    value={formData.message}
                                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                                />
                                <div className="text-right text-xs text-gray-500">{formData.message.length}/500 karakter</div>
                            </div>

                            <button type="submit" className="w-full py-4 bg-gold-DEFAULT text-matte font-bold uppercase tracking-widest rounded-full hover:bg-gold-light transition-all transform hover:scale-[1.02]">
                                Mesaj Gönder
                            </button>
                        </form>
                    </motion.div>
                </div>
            </div>
        </section>
    );
};

export default ContactSection;
