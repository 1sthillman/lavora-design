import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';

const TimelineSection = () => {
    const milestones = [
        {
            year: '1998',
            title: 'Kuruluş',
            description: 'Lavora Design, lüks mobilya sektöründe yolculuğuna başladı',
            icon: 'ri-rocket-line',
        },
        {
            year: '2005',
            title: 'İlk Showroom',
            description: 'İstanbul\'da prestijli showroom açılışı gerçekleştirildi',
            icon: 'ri-store-2-line',
        },
        {
            year: '2010',
            title: 'Uluslararası Genişleme',
            description: 'Avrupa ve Orta Doğu pazarlarına ihracat başladı',
            icon: 'ri-global-line',
        },
        {
            year: '2018',
            title: 'Ödüller',
            description: 'Mükemmellik ve Tasarım kategorisinde 3 büyük ödül',
            icon: 'ri-award-fill',
        },
        {
            year: '2025',
            title: 'Dijital Dönüşüm',
            description: 'V3.0 Modern Online Showroom lansmanı',
            icon: 'ri-macbook-line',
        },
    ];

    return (
        <section className="relative py-24 bg-gradient-to-br from-matte via-nardo-dark to-matte overflow-hidden">
            <div className="container mx-auto px-6 relative">
                <div className="text-center mb-20">
                    <span className="text-gold-DEFAULT text-xs tracking-widest uppercase mb-4 block">Hikayemiz</span>
                    <h2 className="text-5xl font-playfair text-white mb-6">Yolculuğumuz</h2>
                    <p className="text-gray-400 font-montserrat">25 yılı aşkın deneyimimizle lüks mobilya sektöründe iz bıraktık</p>
                </div>

                {/* Vertical timeline line */}
                <div className="absolute left-1/2 top-40 bottom-20 w-[1px] bg-gradient-to-b from-transparent via-gold-DEFAULT/30 to-transparent hidden md:block"></div>

                <div className="space-y-12">
                    {milestones.map((milestone, index) => (
                        <motion.div
                            key={milestone.year}
                            initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true, margin: '-50px' }}
                            className={`relative flex items-center gap-8 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} flex-col`}
                        >
                            {/* Year Bubble */}
                            <div className="w-24 h-24 rounded-full border border-gold-DEFAULT/30 bg-black/50 backdrop-blur-sm flex items-center justify-center relative z-10 shrink-0 shadow-[0_0_30px_rgba(184,148,31,0.1)]">
                                <span className="font-playfair font-bold text-gold-DEFAULT text-xl">{milestone.year}</span>
                            </div>

                            {/* Content Card */}
                            <div className={`flex-1 p-8 bg-white/5 border border-white/5 rounded-lg hover:border-gold-DEFAULT/30 transition-colors w-full ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'} text-center group`}>
                                <div className={`flex flex-col ${index % 2 === 0 ? 'md:items-end' : 'md:items-start'} items-center`}>
                                    <i className={`${milestone.icon} text-3xl text-gold-DEFAULT mb-4 opacity-80 group-hover:opacity-100 transition-opacity`}></i>
                                    <h3 className="text-2xl font-playfair text-white mb-2">{milestone.title}</h3>
                                    <p className="text-gray-400 text-sm font-montserrat leading-relaxed">{milestone.description}</p>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default TimelineSection;
