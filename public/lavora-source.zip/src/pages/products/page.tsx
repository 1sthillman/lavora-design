import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

const Products = () => {
    const [selectedCategory, setSelectedCategory] = useState('Tümü');
    const [searchQuery, setSearchQuery] = useState('');

    useEffect(() => {
        window.scrollTo(0, 0);
        // Parse URL params for category
        const params = new URLSearchParams(window.location.search);
        const cat = params.get('category');
        if (cat) setSelectedCategory(cat);
    }, []);

    const categories = ['Tümü', 'Mutfak', 'Salon', 'Yatak Odası', 'Ofis', 'Bahçe'];

    // Generated High-Quality Product Data (25+ items)
    const products = [
        {
            id: 1,
            name: 'Noir Modern Mutfak',
            category: 'Mutfak',
            description: 'Mat siyah lake kaplama, soft-close menteşe sistemi ve altın detaylar.',
            image: 'https://images.unsplash.com/photo-1556911220-bff31c812dba?q=80&w=800',
            price: '₺185.000',
        },
        {
            id: 2,
            name: 'Grande Mermer Ada',
            category: 'Mutfak',
            description: 'İtalyan Carrara mermeri ve entegre şarap soğutuculu ada ünitesi.',
            image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?q=80&w=800',
            price: '₺120.000',
        },
        {
            id: 3,
            name: 'Venedik Chester Koltuk',
            category: 'Salon',
            description: 'Hakiki deri, el işçiliği kapitone detaylar ve masif ahşap ayaklar.',
            image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=800',
            price: '₺65.000',
        },
        {
            id: 4,
            name: 'Royal Yatak Odası',
            category: 'Yatak Odası',
            description: 'Kadife başlık, pirinç detaylı komodinler ve geniş gardırop.',
            image: 'https://images.unsplash.com/photo-1505693416388-b0346efee971?q=80&w=800',
            price: '₺95.000',
        },
        {
            id: 5,
            name: 'Executive Ofis Masası',
            category: 'Ofis',
            description: 'Ceviz kaplama, deri sümen ve gizli kablo kanalları.',
            image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?q=80&w=800',
            price: '₺45.000',
        },
        {
            id: 6,
            name: 'Zen Bahçe Oturma Grubu',
            category: 'Bahçe',
            description: 'Teak ağacı iskelet, su itici kumaş ve modüler tasarım.',
            image: 'https://images.unsplash.com/photo-1600210491892-03d54cc0fea0?q=80&w=800',
            price: '₺55.000',
        },
        {
            id: 7,
            name: 'Milano TV Ünitesi',
            category: 'Salon',
            description: 'Antrasit lake, LED aydınlatmalı raflar ve şömine entegrasyonu.',
            image: 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?q=80&w=800',
            price: '₺35.000'
        },
        {
            id: 8,
            name: 'Loft Kitaplık',
            category: 'Ofis',
            description: 'Metal iskelet, masif meşe raflar ve endüstriyel tasarım.',
            image: 'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?q=80&w=800',
            price: '₺28.000'
        },
        {
            id: 9,
            name: 'Avangart Yemek Masası',
            category: 'Salon',
            description: '12 kişilik, varaklı ayaklar ve cam tabla.',
            image: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4f9d?q=80&w=800',
            price: '₺78.000'
        },
        {
            id: 10,
            name: 'Mimalist Makyaj Masası',
            category: 'Yatak Odası',
            description: 'Yuvarlak ayna, pudra rengi lake ve puf dahil.',
            image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=800',
            price: '₺22.000'
        },
        {
            id: 11,
            name: 'Chef Professional Mutfak',
            category: 'Mutfak',
            description: 'Paslanmaz çelik tezgahlar ve endüstriyel cihazlar.',
            image: 'https://images.unsplash.com/photo-1560184897-ae75f418493e?q=80&w=800',
            price: '₺210.000'
        },
        {
            id: 12,
            name: 'Daybed Bahçe Yatağı',
            category: 'Bahçe',
            description: 'Gölgelikli, rattan örgü ve konforlu minderler.',
            image: 'https://images.unsplash.com/photo-1583608205776-bfd35f0d9f83?q=80&w=800',
            price: '₺42.000'
        },
        {
            id: 13,
            name: 'Sultan Berjer',
            category: 'Salon',
            description: 'Altın varaklı, bordo kadife ve klasik motifler.',
            image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=800',
            price: '₺18.000'
        },
        {
            id: 14,
            name: 'Modern Konsol',
            category: 'Yatak Odası',
            description: 'Ahşap ve metalin uyumu, geniş depolama.',
            image: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?q=80&w=800',
            price: '₺15.000'
        },
        {
            id: 15,
            name: 'Toplantı Masası',
            category: 'Ofis',
            description: ' Oval tasarım, entegre priz sistemi ve deri detaylar.',
            image: 'https://images.unsplash.com/photo-1497215842964-222b430dc094?q=80&w=800',
            price: '₺55.000'
        },
        {
            id: 16,
            name: 'Barista Corner',
            category: 'Mutfak',
            description: ' Kahve köşesi için özel tasarım, raf ve dolap sistemi.',
            image: 'https://images.unsplash.com/photo-1484154218962-a1c002085d2f?q=80&w=800',
            price: '₺12.000'
        },
        {
            id: 17,
            name: 'L-Tipi Kanepe',
            category: 'Salon',
            description: 'Modüler, keten kumaş ve kuş tüyü dolgu.',
            image: 'https://images.unsplash.com/photo-1560448205-4d9b3e6bb6db?q=80&w=800',
            price: '₺48.000'
        },
        {
            id: 18,
            name: 'Ebeveyn Banyo Dolabı',
            category: 'Yatak Odası', // Categorized as Bedroom suite or similar
            description: 'Çift lavabolu, aynalı ve LED aydınlatmalı.',
            image: 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?q=80&w=800',
            price: '₺25.000'
        },
        {
            id: 19,
            name: 'CEO Koltuğu',
            category: 'Ofis',
            description: 'Ergonomik, hakiki deri ve masaj özellikli.',
            image: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?q=80&w=800',
            price: '₺22.000'
        },
        {
            id: 20,
            name: 'Fire Pit Masa',
            category: 'Bahçe',
            description: 'Ortası şömineli beton masa.',
            image: 'https://images.unsplash.com/photo-1560185007-c5ca9d2c014d?q=80&w=800',
            price: '₺32.000'
        },
        {
            id: 21,
            name: 'Country Mutfak',
            category: 'Mutfak',
            description: 'Pastel tonlar, porselen kulplar ve açık raflar.',
            image: 'https://images.unsplash.com/photo-1556909212-d5b604d0c90d?q=80&w=800',
            price: '₺90.000'
        },
        {
            id: 22,
            name: 'Berjer Seti',
            category: 'Salon',
            description: 'Döner mekanizmalı, modern tasarım ikili set.',
            image: 'https://images.unsplash.com/photo-1567016432779-094069958ea5?q=80&w=800',
            price: '₺24.000'
        },
        {
            id: 23,
            name: 'Gardırop Sistemi',
            category: 'Yatak Odası',
            description: 'Füme cam kapaklar ve sensörlü aydınlatma.',
            image: 'https://images.unsplash.com/photo-1558603668-6570496b66f8?q=80&w=800',
            price: '₺58.000'
        },
        {
            id: 24,
            name: 'Bekleme Alanı',
            category: 'Ofis',
            description: 'Şık ve konforlu misafir ağırlama grubu.',
            image: 'https://images.unsplash.com/photo-1604328698692-f76ea94d8e76?q=80&w=800',
            price: '₺30.000'
        },
        {
            id: 25,
            name: 'Salıncak',
            category: 'Bahçe',
            description: 'Makrome örgü, tek kişilik konfor alanı.',
            image: 'https://images.unsplash.com/photo-1596178065887-1198b6148b2e?q=80&w=800',
            price: '₺8.500'
        }
    ];

    const filteredProducts = products.filter((product) => {
        const matchesCategory = selectedCategory === 'Tümü' || product.category === selectedCategory;
        const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            product.description.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    return (
        <div className="min-h-screen bg-gradient-to-br from-nardo-dark via-matte to-nardo-dark text-white pt-24 pb-20 px-6">
            <Navbar />

            <div className="container mx-auto">
                {/* Header */}
                <div className="text-center mb-16">
                    <span className="text-gold-DEFAULT text-xs tracking-widest uppercase mb-4 block">Koleksiyonlar</span>
                    <h1 className="text-4xl md:text-6xl font-playfair mb-6">Tüm Ürünler</h1>
                    <div className="max-w-md mx-auto relative group">
                        <input
                            type="text"
                            placeholder="Ürün Ara..."
                            className="w-full bg-white/5 border border-white/10 rounded-full py-3 px-6 pl-12 text-white outline-none focus:border-gold-DEFAULT transition-colors"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                        <i className="ri-search-line absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-hover:text-gold-DEFAULT transition-colors"></i>
                    </div>
                </div>

                {/* Categories */}
                <div className="flex flex-wrap justify-center gap-4 mb-16">
                    {categories.map(cat => (
                        <button
                            key={cat}
                            onClick={() => setSelectedCategory(cat)}
                            className={`px-6 py-2 rounded-full border text-sm uppercase tracking-wider transition-all duration-300 ${selectedCategory === cat
                                    ? 'bg-gold-DEFAULT border-gold-DEFAULT text-matte font-bold'
                                    : 'border-white/10 text-gray-400 hover:border-gold-DEFAULT/50 hover:text-white'
                                }`}
                        >
                            {cat}
                        </button>
                    ))}
                </div>

                {/* Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                    <AnimatePresence mode="popLayout">
                        {filteredProducts.map((product) => (
                            <motion.div
                                layout
                                key={product.id}
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.9 }}
                                transition={{ duration: 0.3 }}
                                className="group bg-white/5 border border-white/5 rounded-lg overflow-hidden hover:border-gold-DEFAULT/30 transition-all cursor-pointer flex flex-col h-full"
                            >
                                <div className="h-64 overflow-hidden relative">
                                    <img
                                        src={product.image}
                                        alt={product.name}
                                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                                    />
                                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                        <span className="px-6 py-2 bg-gold-DEFAULT text-matte font-bold uppercase tracking-widest text-xs rounded-full transform translate-y-4 group-hover:translate-y-0 transition-transform">İncele</span>
                                    </div>
                                </div>
                                <div className="p-6 flex flex-col flex-1">
                                    <div className="flex justify-between items-start mb-2">
                                        <span className="text-gold-DEFAULT text-xs uppercase tracking-widest">{product.category}</span>
                                    </div>
                                    <h3 className="text-xl font-playfair text-white mb-2 group-hover:text-gold-DEFAULT transition-colors">{product.name}</h3>
                                    <p className="text-gray-400 text-sm font-montserrat mb-4 flex-1">{product.description}</p>
                                    <div className="pt-4 border-t border-white/5 flex justify-between items-center">
                                        <span className="text-lg font-medium text-white">{product.price}</span>
                                        <button className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-gold-DEFAULT hover:text-matte transition-colors">
                                            <i className="ri-arrow-right-line"></i>
                                        </button>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </div>

                {filteredProducts.length === 0 && (
                    <div className="text-center py-20 text-gray-500">
                        <i className="ri-search-2-line text-4xl mb-4 block"></i>
                        <p>Aradığınız kriterlere uygun ürün bulunamadı.</p>
                    </div>
                )}

            </div>
            <Footer />
        </div>
    );
};

export default Products;
