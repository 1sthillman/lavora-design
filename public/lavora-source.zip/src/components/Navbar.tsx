import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const Navbar = () => {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const location = useLocation();

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const navLinks = [
        { name: 'Ana Sayfa', path: '/' },
        { name: 'Ürünler', path: '/products' },
        { name: 'Galeri', path: '/gallery' },
        { name: 'İletişim', path: '/#contact' },
        { name: 'Kaynak Kod', path: '/source-code' },
    ];

    return (
        <>
            <motion.nav
                initial={{ y: -100 }}
                animate={{ y: 0 }}
                className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'bg-matte/95 backdrop-blur-md shadow-lg py-4' : 'bg-transparent py-6'
                    }`}
            >
                <div className="container mx-auto px-6 flex items-center justify-between">
                    <Link to="/" className="flex items-center gap-3 group">
                        <div className="w-10 h-10 bg-gold-DEFAULT flex items-center justify-center rounded-sm">
                            <span className="font-playfair text-2xl font-bold text-matte">L</span>
                        </div>
                        <div className="flex flex-col">
                            <span className="font-playfair text-xl font-bold text-white tracking-widest group-hover:text-gold-light transition-colors">LAVORA DESIGN</span>
                            <span className="font-montserrat text-[10px] text-gray-400 tracking-[0.2em] uppercase">Premium Mobilya</span>
                        </div>
                    </Link>

                    {/* Desktop Menu */}
                    <div className="hidden md:flex items-center space-x-8">
                        {navLinks.map((link) => (
                            <Link
                                key={link.name}
                                to={link.path}
                                className="text-sm uppercase tracking-widest text-white/80 hover:text-gold-DEFAULT transition-colors relative group"
                            >
                                {link.name}
                                <span className="absolute -bottom-2 left-0 w-0 h-[1px] bg-gold-DEFAULT transition-all duration-300 group-hover:w-full"></span>
                            </Link>
                        ))}
                    </div>

                    {/* Mobile Menu Toggle */}
                    <button
                        className="md:hidden text-white p-2"
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                    >
                        {isMobileMenuOpen ? (
                            <i className="ri-close-line text-2xl"></i>
                        ) : (
                            <i className="ri-menu-4-line text-2xl"></i>
                        )}
                    </button>
                </div>
            </motion.nav>

            {/* Mobile menu overlay */}
            <AnimatePresence>
                {isMobileMenuOpen && (
                    <motion.div
                        initial={{ opacity: 0, x: '100%' }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: '100%' }}
                        className="fixed inset-0 z-40 md:hidden bg-matte/98 backdrop-blur-xl flex items-center justify-center p-8"
                    >
                        <div className="flex flex-col items-center space-y-8 text-center">
                            {navLinks.map((link) => (
                                <Link
                                    key={link.name}
                                    to={link.path}
                                    className="text-2xl font-playfair text-white hover:text-gold-DEFAULT transition-colors"
                                    onClick={() => setIsMobileMenuOpen(false)}
                                >
                                    {link.name}
                                </Link>
                            ))}
                            <button
                                className="absolute top-8 right-8 text-white/50 hover:text-white"
                                onClick={() => setIsMobileMenuOpen(false)}
                            >
                                <i className="ri-close-circle-line text-4xl"></i>
                            </button>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
};

export default Navbar;
